RUPESH DUBEY PERSONAL WEBSITE — VERSION 2

Files:
- index.html — website
- profile.jpg — profile photo used by the website

To update GitHub Pages:
1. Upload/replace index.html in your Rupesh720.github.io repository.
2. Upload profile.jpg to the repository root.
3. Commit both changes.
4. GitHub Pages will deploy the update automatically.

The GitHub repository remains under the owner's account.
